/** @file
 * API flags and functions for specifying deployment modes.
 * 
 * @author Tyson Jones
 */

#include "../../include/modes.h"






int modeflag::USE_AUTO = -1;
