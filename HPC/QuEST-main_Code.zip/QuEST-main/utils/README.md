
This folder contains auxiliary files used by QuEST, such as documentation configuration files.
